(function (Drupal) {
  Drupal.behaviors.dashboardBehaviour = {
    attach(context) {
      console.log("Dashboard JS Loaded");
    }
  };
})(Drupal);
