<?php
namespace Drupal\jobshedular\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class JobShedularForm extends FormBase {

  public function getFormId() {
    return 'jobshedular_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {

    // Get current count
    $count = \Drupal::state()->get('jobshedular_job_count', 0);

    $form['job_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Job Name'),
      '#required' => TRUE,
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit Job (' . $count . ')'),
    ];

    return $form;
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {

    // Add job to queue
    $queue = \Drupal::queue('jobshedular_background_queue');
    $queue->createItem([
      'job_name' => $form_state->getValue('job_name'),
      'uid' => \Drupal::currentUser()->id(),
      'created' => time(),
    ]);

    $this->messenger()->addStatus(
      $this->t('Job added successfully. It will be processed by cron.')
    );
  }
}
