<?php
namespace Drupal\jobshedular\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;

/**
 * @QueueWorker(
 *   id = "jobshedular_background_queue",
 *   title = @Translation("Job Shedular Background Queue"),
 *   cron = {"time" = 30}
 * )
 */
class JobShedularQueueWorker extends QueueWorkerBase {

  public function processItem($data) {

    // Log job processing
    \Drupal::logger('jobshedular')->notice(
      'Processing job: @job',
      ['@job' => $data['job_name']]
    );

    // Update job counter
    $count = \Drupal::state()->get('jobshedular_job_count', 0);
    \Drupal::state()->set('jobshedular_job_count', $count + 1);

    // Place heavy logic here:
    // - API calls
    // - Workflow update
    // - Status change
  }
}
